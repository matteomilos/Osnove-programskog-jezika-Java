package hr.fer.zemris.java.hw01;

import static org.junit.Assert.*;

import org.junit.Test;

public class RectangleTest {

	// @Test
	// public void test() {
	// fail("Not yet implemented");
	// }

}
